package siovim;

/**
 * «abstract» Usuario
 *
 * Clase base de la jerarquía de herencia SIOVIM.
 * Define los atributos comunes y el contrato de autenticación
 * que deben implementar Cliente y Empleado.
 *
 * Atributos del diagrama:
 *   - id        : int
 *   - nombre    : String
 *   - correo    : String
 *   - telefono  : String
 *
 * Métodos del diagrama:
 *   + autenticar(clave: String): boolean   → abstracto
 *   + actualizarPerfil(nombre, correo, tel): void
 */
public abstract class Usuario {

    // ── Encapsulamiento: atributos privados ──────────────────────────────────
    private int    id;
    private String nombre;
    private String correo;
    private String telefono;

    // ── Constructor ──────────────────────────────────────────────────────────
    public Usuario(int id, String nombre, String correo, String telefono) {
        this.id       = id;
        this.nombre   = nombre;
        this.correo   = correo;
        this.telefono = telefono;
    }

    // ── Método abstracto (polimorfismo) ──────────────────────────────────────
    public abstract boolean autenticar(String clave);

    // ── Método concreto compartido ───────────────────────────────────────────
    public void actualizarPerfil(String nombre, String correo, String telefono) {
        this.nombre   = nombre;
        this.correo   = correo;
        this.telefono = telefono;
        System.out.println("[Usuario] Perfil actualizado → " + this.nombre);
    }

    // ── Getters / Setters ────────────────────────────────────────────────────
    public int    getId()       { return id; }
    public String getNombre()   { return nombre; }
    public String getCorreo()   { return correo; }
    public String getTelefono() { return telefono; }

    public void setNombre(String nombre)     { this.nombre   = nombre; }
    public void setCorreo(String correo)     { this.correo   = correo; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[id=" + id + ", nombre=" + nombre + "]";
    }
}
