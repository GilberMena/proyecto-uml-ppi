package siovim;

import java.time.LocalDate;

/**
 * Reserva
 *
 * Núcleo operativo de SIOVIM. Vincula un Cliente con un PaqueteTuristico
 * y gestiona el ciclo de vida del servicio.
 *
 * Relaciones del diagrama:
 *   - Cliente      → Reserva  : asociación 1 a 1..*
 *   - Reserva      → Paquete  : asociación 1 a 1..*
 *   - Reserva      ◆→ Pago    : composición (el pago es parte de la reserva)
 *   - Reserva      «usa» EstadoReserva
 *
 * Atributos del diagrama:
 *   - idReserva     : String
 *   - fecha         : LocalDate
 *   - estado        : EstadoReserva
 *   - totalPersonas : int
 *
 * Métodos del diagrama:
 *   + create(): boolean
 *   + cancel(): void
 *   + confirm(): boolean
 *   + confirmarPago(): boolean
 */
public class Reserva {

    private String           idReserva;
    private LocalDate        fecha;
    private EstadoReserva    estado;
    private int              totalPersonas;

    // Asociaciones navegables desde Reserva
    private Cliente          cliente;        // asociación: 1 cliente por reserva
    private PaqueteTuristico paquete;        // asociación: 1 paquete por reserva
    private Pago             pago;           // composición: 1 pago (puede ser null al inicio)

    // ── Constructor ──────────────────────────────────────────────────────────
    public Reserva(String idReserva, LocalDate fecha,
                   int totalPersonas, Cliente cliente, PaqueteTuristico paquete) {
        this.idReserva     = idReserva;
        this.fecha         = fecha;
        this.totalPersonas = totalPersonas;
        this.cliente       = cliente;
        this.paquete       = paquete;
        this.estado        = EstadoReserva.PRERRESERVA;
    }

    // ── Métodos del diagrama ─────────────────────────────────────────────────

    /**
     * Crea la reserva verificando disponibilidad de cupos.
     * Si hay cupos pasa a PENDIENTE_PAGO; si no, a LISTA_ESPERA.
     */
    public boolean create() {
        if (paquete.verificarDisponibilidad(totalPersonas)) {
            estado = EstadoReserva.PENDIENTE_PAGO;
            System.out.println("[Reserva] " + idReserva + " creada → esperando pago.");
            return true;
        }
        estado = EstadoReserva.LISTA_ESPERA;
        System.out.println("[Reserva] " + idReserva + " sin cupos → lista de espera.");
        return false;
    }

    /** Cancela la reserva y libera los cupos si estaba confirmada. */
    public void cancel() {
        if (estado == EstadoReserva.CONFIRMADA) {
            paquete.actualizarCupos(-totalPersonas); // devuelve cupos
        }
        estado = EstadoReserva.CANCELADA;
        System.out.println("[Reserva] " + idReserva + " cancelada.");
    }

    /**
     * Confirma la reserva operativamente (post-pago).
     * Solo válido si el estado es CONFIRMADA.
     */
    public boolean confirm() {
        if (estado == EstadoReserva.CONFIRMADA) {
            System.out.println("[Reserva] " + idReserva + " confirmada y lista para operación.");
            return true;
        }
        System.out.println("[Reserva] No se puede confirmar — estado actual: " + estado);
        return false;
    }

    /**
     * Procesa el pago asociado.
     * Si el pago es exitoso descuenta cupos y pasa a CONFIRMADA.
     */
    public boolean confirmarPago() {
        if (pago == null) {
            System.out.println("[Reserva] No hay pago asignado a " + idReserva);
            return false;
        }
        if (pago.procesar()) {
            paquete.actualizarCupos(totalPersonas);
            estado = EstadoReserva.CONFIRMADA;
            System.out.println("[Reserva] Pago confirmado → reserva CONFIRMADA.");
            return true;
        }
        return false;
    }

    // ── Getters / Setters ────────────────────────────────────────────────────
    public String           getIdReserva()     { return idReserva; }
    public LocalDate        getFecha()         { return fecha; }
    public EstadoReserva    getEstado()        { return estado; }
    public int              getTotalPersonas() { return totalPersonas; }
    public Cliente          getCliente()       { return cliente; }
    public PaqueteTuristico getPaquete()       { return paquete; }
    public Pago             getPago()          { return pago; }

    /** Asigna el pago (composición: la reserva controla el ciclo de vida del pago). */
    public void setPago(Pago pago) { this.pago = pago; }

    @Override
    public String toString() {
        return "Reserva[id=" + idReserva
             + ", fecha=" + fecha
             + ", personas=" + totalPersonas
             + ", estado=" + estado
             + ", paquete=" + paquete.getNombre()
             + ", cliente=" + cliente.getNombre() + "]";
    }
}
