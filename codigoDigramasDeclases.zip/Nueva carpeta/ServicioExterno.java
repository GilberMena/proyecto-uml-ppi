package siovim;

/**
 * «interface» ServicioExterno
 * Contrato que deben cumplir todos los proveedores externos del sistema.
 */
public interface ServicioExterno {

    /**
     * Confirma que el proveedor puede atender la reserva indicada.
     * @param idReserva identificador único de la reserva
     * @return true si el servicio queda confirmado
     */
    boolean confirmarServicio(String idReserva);
}
