package siovim;

/**
 * Pago
 *
 * Registra y procesa el cobro asociado a una reserva.
 * Relación de composición con Reserva (un pago pertenece a una sola reserva).
 *
 * Atributos del diagrama:
 *   - idPago  : int
 *   - monto   : decimal → double en Java
 *   - metodo  : String  (ej: "PSE", "transferencia", "efectivo")
 *   - estado  : String  (ej: "pendiente", "procesado", "rechazado")
 *
 * Métodos del diagrama:
 *   + registrar(): boolean
 *   + validar(): boolean
 *   + procesar(): boolean
 */
public class Pago {

    private int    idPago;
    private double monto;
    private String metodo;
    private String estado;

    // ── Constructor ──────────────────────────────────────────────────────────
    public Pago(int idPago, double monto, String metodo) {
        this.idPago = idPago;
        this.monto  = monto;
        this.metodo = metodo;
        this.estado = "pendiente";
    }

    // ── Métodos del diagrama ─────────────────────────────────────────────────

    /** Registra el intento de pago en el sistema. */
    public boolean registrar() {
        System.out.println("[Pago] Registrado: $" + monto + " vía " + metodo);
        return true;
    }

    /** Valida que el monto sea positivo y el método sea reconocido. */
    public boolean validar() {
        boolean montoOk  = monto > 0;
        boolean metodoOk = metodo != null && !metodo.isBlank();
        return montoOk && metodoOk;
    }

    /** Procesa el pago: valida y cambia el estado al resultado. */
    public boolean procesar() {
        if (validar()) {
            estado = "procesado";
            System.out.println("[Pago] Procesado exitosamente: $" + monto);
            return true;
        }
        estado = "rechazado";
        System.out.println("[Pago] Rechazado — datos inválidos.");
        return false;
    }

    // ── Getters / Setters ────────────────────────────────────────────────────
    public int    getIdPago()  { return idPago; }
    public double getMonto()   { return monto; }
    public String getMetodo()  { return metodo; }
    public String getEstado()  { return estado; }

    @Override
    public String toString() {
        return "Pago[id=" + idPago + ", $" + monto + ", " + metodo + ", " + estado + "]";
    }
}
