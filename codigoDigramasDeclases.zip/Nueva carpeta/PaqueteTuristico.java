package siovim;

/**
 * PaqueteTuristico
 *
 * Representa un plan turístico comercializado por Viajes Vive Mar.
 * Un paquete puede estar asociado a 1..* reservas (cardinalidad del diagrama).
 *
 * Atributos del diagrama:
 *   - idPaquete         : int
 *   - nombre            : String
 *   - precioBase        : decimal  → double en Java
 *   - cuposDisponibles  : int
 *
 * Métodos del diagrama:
 *   + calcularTarifa(personas: int): double
 *   + verificarDisponibilidad(n: int): boolean
 *   + actualizarCupos(n: int): void
 */
public class PaqueteTuristico {

    private int    idPaquete;
    private String nombre;
    private double precioBase;
    private int    cuposDisponibles;

    // ── Constructor ──────────────────────────────────────────────────────────
    public PaqueteTuristico(int idPaquete, String nombre,
                            double precioBase, int cuposDisponibles) {
        this.idPaquete        = idPaquete;
        this.nombre           = nombre;
        this.precioBase       = precioBase;
        this.cuposDisponibles = cuposDisponibles;
    }

    // ── Métodos del diagrama ─────────────────────────────────────────────────

    /** Calcula la tarifa total. Aplica 5 % de descuento para grupos ≥ 5. */
    public double calcularTarifa(int personas) {
        double tarifa = precioBase * personas;
        if (personas >= 5) tarifa *= 0.95;
        return tarifa;
    }

    /** Devuelve true si hay suficientes cupos para la cantidad solicitada. */
    public boolean verificarDisponibilidad(int n) {
        return cuposDisponibles >= n;
    }

    /** Descuenta los cupos reservados del total disponible. */
    public void actualizarCupos(int n) {
        if (n > cuposDisponibles) {
            System.out.println("[PaqueteTuristico] No hay cupos suficientes.");
            return;
        }
        cuposDisponibles -= n;
        System.out.println("[PaqueteTuristico] Cupos restantes: " + cuposDisponibles);
    }

    // ── Getters / Setters ────────────────────────────────────────────────────
    public int    getIdPaquete()        { return idPaquete; }
    public String getNombre()           { return nombre; }
    public double getPrecioBase()       { return precioBase; }
    public int    getCuposDisponibles() { return cuposDisponibles; }

    public void setNombre(String nombre)          { this.nombre   = nombre; }
    public void setPrecioBase(double precioBase)  { this.precioBase = precioBase; }

    @Override
    public String toString() {
        return "PaqueteTuristico[id=" + idPaquete
             + ", nombre=" + nombre
             + ", precio=$" + precioBase
             + ", cupos=" + cuposDisponibles + "]";
    }
}
