package siovim;

/**
 * «enumeration» EstadoReserva
 * Representa los estados posibles del ciclo de vida de una reserva en SIOVIM.
 */
public enum EstadoReserva {
    PRERRESERVA,
    PENDIENTE_PAGO,
    CONFIRMADA,
    LISTA_ESPERA,
    CANCELADA
}
