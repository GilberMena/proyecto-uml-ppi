package siovim;

import java.util.ArrayList;
import java.util.List;

/**
 * Cliente
 *
 * Extiende Usuario. Representa al viajero que adquiere paquetes turísticos.
 * Mantiene una colección de reservas (asociación 1 → 1..*).
 *
 * Atributos del diagrama:
 *   - preferencias : String
 *   - documento    : String
 *
 * Métodos del diagrama:
 *   + solicitarReserva(r: Reserva): void
 *   + verReservas(): List<Reserva>
 *   + consultarVoucher(idReserva: String): void
 *
 * Herencia: Cliente → Usuario
 */
public class Cliente extends Usuario {

    private String        preferencias;
    private String        documento;

    // Asociación 1 → 1..* con Reserva
    private List<Reserva> reservas;

    // ── Constructor ──────────────────────────────────────────────────────────
    public Cliente(int id, String nombre, String correo, String telefono,
                   String preferencias, String documento) {
        super(id, nombre, correo, telefono);
        this.preferencias = preferencias;
        this.documento    = documento;
        this.reservas     = new ArrayList<>();
    }

    // ── Polimorfismo: implementación concreta de autenticar() ────────────────
    @Override
    public boolean autenticar(String clave) {
        boolean ok = documento.equals(clave);
        System.out.println("[Cliente] Autenticación " + getNombre()
                + ": " + (ok ? "EXITOSA" : "FALLIDA"));
        return ok;
    }

    // ── Métodos del diagrama ─────────────────────────────────────────────────

    /** Agrega la reserva a la colección del cliente. */
    public void solicitarReserva(Reserva r) {
        reservas.add(r);
        System.out.println("[Cliente] Reserva " + r.getIdReserva()
                + " vinculada a " + getNombre());
    }

    /** Devuelve todas las reservas del cliente. */
    public List<Reserva> verReservas() {
        return reservas;
    }

    /** Muestra el voucher de la reserva indicada si está CONFIRMADA. */
    public void consultarVoucher(String idReserva) {
        reservas.stream()
                .filter(r -> r.getIdReserva().equals(idReserva))
                .findFirst()
                .ifPresentOrElse(
                    r -> {
                        if (r.getEstado() == EstadoReserva.CONFIRMADA) {
                            System.out.println("===== VOUCHER =====");
                            System.out.println(r);
                            System.out.println("===================");
                        } else {
                            System.out.println("[Cliente] Reserva " + idReserva
                                    + " aún no está confirmada.");
                        }
                    },
                    () -> System.out.println("[Cliente] Reserva no encontrada: " + idReserva)
                );
    }

    // ── Getters / Setters ────────────────────────────────────────────────────
    public String getPreferencias() { return preferencias; }
    public String getDocumento()    { return documento; }

    public void setPreferencias(String preferencias) { this.preferencias = preferencias; }
}
